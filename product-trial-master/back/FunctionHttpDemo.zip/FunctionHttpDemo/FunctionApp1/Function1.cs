using System.Text;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure;

namespace FunctionApp1
{
    public class Function1
    {
        private readonly ILogger _logger;

        public Function1(ILogger<Function1> logger)
        {
            _logger = logger;
        }

        [Function("UploadFileFunction")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            // Configuraci�n
            string containerName = "samples-workitems";
            string connectionString = "UseDevelopmentStorage=true";

            // Contenido del archivo a crear
            string content = "Ceci est un test d'�criture dans un fichier blob depuis Azure Function.";
            byte[] contentBytes = Encoding.UTF8.GetBytes(content);
            using var contentStream = new MemoryStream(contentBytes);

            // Metadata que se agregar�
            var metadata = new Dictionary<string, string>
            {
                { "documentType", "test" },
                { "createdBy", "AzureFunction" },
                { "dateCreation", DateTime.UtcNow.ToString("yyyy-MM-dd") }
            };

            // Inicializa cliente del contenedor y blob
            var containerClient = new BlobContainerClient(connectionString, containerName);
            await containerClient.CreateIfNotExistsAsync();

            string blobName = $"generated-{DateTime.UtcNow:yyyyMMddHHmmss}.txt";
            var blobClient = containerClient.GetBlobClient(blobName);

            // Subida del contenido
            await blobClient.UploadAsync(contentStream, overwrite: true);

            // Asignar metadata
            await blobClient.SetMetadataAsync(metadata);

            _logger.LogInformation($"Fichier '{blobName}' cr�� avec metadata.");

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync($"Fichier '{blobName}' cr�� avec succ�s dans Azure Blob Storage.");
            return response;
        }
    }
}
