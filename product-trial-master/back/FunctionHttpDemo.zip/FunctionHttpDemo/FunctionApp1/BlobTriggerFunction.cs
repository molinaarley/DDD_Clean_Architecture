using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Specialized;
using Azure;
using System.Collections.Generic;

namespace FunctionApp1;

public class BlobTriggerFunction
{
    private readonly ILogger<BlobTriggerFunction> _logger;

    public BlobTriggerFunction(ILogger<BlobTriggerFunction> logger)
    {
        _logger = logger;
    }

    [Function(nameof(BlobTriggerFunction))]
    public async Task Run(
        [BlobTrigger("samples-workitems/{name}", Connection = "AzureWebJobsStorage")] Stream stream,
        string name)
    {
        // Leer el contenido del blob
        using var blobStreamReader = new StreamReader(stream);
        var content = await blobStreamReader.ReadToEndAsync();
        _logger.LogInformation("Contenido del blob '{name}':\n{content}", name, content);

        // Crear un BlobClient para acceder al blob (usamos el emulador en este ejemplo)
        string connectionString = "UseDevelopmentStorage=true";
        string containerName = "samples-workitems";

        var blobClient = new BlobClient(connectionString, containerName, name);

        try
        {
            var properties = await blobClient.GetPropertiesAsync();
            IDictionary<string, string> metadata = properties.Value.Metadata;

            if (metadata.Count == 0)
            {
                _logger.LogInformation("No se encontraron metadatos para el blob '{name}'.", name);
            }
            else
            {
                foreach (var kvp in metadata)
                {
                    _logger.LogInformation("Metadata: {key} = {value}", kvp.Key, kvp.Value);
                }
            }
        }
        catch (RequestFailedException ex)
        {
            _logger.LogError(ex, "Error al obtener los metadatos del blob '{name}'.", name);
        }
    }
}
