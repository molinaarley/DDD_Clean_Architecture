using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading.Tasks;

public static class HttpTriggerFunction
{
    [FunctionName("HttpTriggerFunction")]
    public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("💡 HTTP Trigger ejecutado.");

        string name = req.Query["name"];

        if (string.IsNullOrEmpty(name))
        {
            using var reader = new StreamReader(req.Body);
            var body = await reader.ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(body);
            name = data?.name;
        }

        return name != null
            ? (ActionResult)new OkObjectResult($"Hola, {name}!")
            : new BadRequestObjectResult("Por favor, proporciona un 'name' en la query o el body.");
    }
}
