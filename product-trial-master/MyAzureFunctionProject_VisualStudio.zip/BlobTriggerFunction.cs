using System.IO;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

public static class BlobTriggerFunction
{
    [FunctionName("BlobTriggerFunction")]
    public static void Run(
        [BlobTrigger("fichiers/{name}", Connection = "AzureWebJobsStorage")] Stream myBlob,
        string name,
        ILogger log)
    {
        log.LogInformation($"📁 Archivo recibido: {name}");
        log.LogInformation($"📦 Tamaño: {myBlob.Length} bytes");

        using var reader = new StreamReader(myBlob);
        var content = reader.ReadToEnd();
        log.LogInformation($"Contenido: {content}");
    }
}
